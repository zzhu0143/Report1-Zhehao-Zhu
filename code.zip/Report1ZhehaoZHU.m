clear; close all; clc; rng(5305);
audioPath = 'myAudio.wav';   
if exist(audioPath,'file')
    [x, fs] = audioread(audioPath);
else
    load handel.mat; x = y; fs = Fs; clear y Fs;
end

x = x(:,1);                          
x = x / (max(abs(x))+eps);           
N  = numel(x);
t  = (0:N-1)/fs;


segDur = 8; segStart = 12;
if (segStart + segDur)*fs > N, segStart = 0; end
idx  = (segStart*fs+1) : min((segStart+segDur)*fs, N);
xseg = x(idx);
tseg = (0:numel(xseg)-1)/fs + segStart;

outdir = "figs"; if ~exist(outdir,'dir'), mkdir(outdir); end


figure('Name','Fig1');
subplot(2,1,1);
plot(t, x); grid on; xlabel('Time (s)'); ylabel('Amplitude');
title('Fig.1(a) Original waveform');

subplot(2,1,2);
win  = round(0.03*fs);                  
hop  = round(0.01*fs);                  
nfft = 2^nextpow2(4*win);

w = 0.54 - 0.46*cos(2*pi*(0:win-1)/(max(win-1,1))); w = w(:);

[S, f, tt] = stft_nontbx(xseg, fs, w, hop, nfft);
imagesc(tt + segStart, f, 20*log10(abs(S)+eps)); axis xy;
xlabel('Time (s)'); ylabel('Frequency (Hz)');
title(sprintf('Fig.1(b) Spectrogram (segment %.1f–%.1fs)', segStart, segStart+segDur));
colorbar;

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig1_wave_spectrogram.png'), 'Resolution', 300);


Lwin = round(0.20*fs); shift = round(0.10*fs);   
y1 = xseg(1:min(Lwin, numel(xseg)));
y2 = xseg(1+shift:min(shift+Lwin, numel(xseg)));
[r, lags] = xcorr_basic(y1, y2);                 
[~,imax]  = max(r);
lag_s     = lags(imax)/fs;

figure('Name','Fig2');
subplot(3,1,1);
plot((0:numel(y1)-1)/fs*1e3, y1); grid on;
xlabel('Time (ms)'); ylabel('Amp'); title('Fig.2(a) Segment #1 (0–200 ms)');

subplot(3,1,2);
plot((0:numel(y2)-1)/fs*1e3 + 100, y2); grid on;
xlabel('Time (ms)'); ylabel('Amp'); title('Fig.2(b) Segment #2 (100–300 ms)');

subplot(3,1,3);
plot(lags/fs*1e3, r); grid on;
xlabel('Lag (ms)'); ylabel('XCorr');
title(sprintf('Fig.2(c) Cross-correlation (peak lag = %.1f ms)', lag_s*1e3));

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig2_xcorr.png'), 'Resolution', 300);

yd = xseg(1:3:end);                    
yu = zeros(2*numel(xseg),1);            
yu(1:2:end) = xseg;

td = linspace(0, segDur, numel(yd));
tu = linspace(0, segDur, numel(yu));

figure('Name','Fig3');
subplot(3,1,1); plot(tseg - segStart, xseg); grid on; xlim([0 segDur]);
title('Fig.3(a) Original segment'); xlabel('Time (s)'); ylabel('Amp');

subplot(3,1,2); plot(td, yd); grid on; xlim([0 segDur]);
title('Fig.3(b) Downsampled by 3 (no anti-aliasing)'); xlabel('Time (s)');

subplot(3,1,3); plot(tu, yu); grid on; xlim([0 segDur]);
title('Fig.3(c) Upsampled by 2 (zero insertion)'); xlabel('Time (s)');

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig3_resample_time.png'), 'Resolution', 300);


N0 = numel(xseg);
faxis = linspace(-fs/2, fs/2, N0);
X = fftshift(fft(xseg));
figure('Name','Fig4');
plot(faxis, abs(X)); grid on;
xlabel('Frequency (Hz)'); ylabel('|X(f)|');
title('Fig.4 Magnitude spectrum of the segment (FFT)');

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig4_fft.png'), 'Resolution', 300);


K = 32; k = 0:K-1; n = 0:N0-1;
Wm = exp(-1j*2*pi*(k'/N0)*n);
Xk = Wm * xseg;
fhalf = k/N0*fs;
figure('Name','Fig5');
stem(fhalf, abs(Xk), 'filled'); grid on;
xlabel('Frequency (Hz)'); ylabel('|X_k|');
title('Fig.5 Custom K-point DFT (K=32)');

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig5_customDFT.png'), 'Resolution', 300);


SNRdB = 12;
Psig = mean(xseg.^2);
Pnoi = Psig / (10^(SNRdB/10));
xnoisy = xseg + sqrt(Pnoi)*randn(size(xseg));

figure('Name','Fig6');
subplot(2,1,1); plot(tseg - segStart, xseg); grid on; xlim([0 segDur]);
title('Fig.6(a) Clean segment'); xlabel('Time (s)');
subplot(2,1,2); plot(tseg - segStart, xnoisy); grid on; xlim([0 segDur]);
title(sprintf('Fig.6(b) Noisy segment (SNR = %g dB)', SNRdB)); xlabel('Time (s)');

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig6_awgn.png'), 'Resolution', 300);


fc = min(5000, floor(0.2*fs));          
c  = cos(2*pi*fc*(0:N0-1)/fs).';
s_mod = xseg .* c;                       
s_dem = s_mod .* c;                      

lpN = 101; wc = 0.2;                     
m = -(lpN-1)/2 : (lpN-1)/2;
h_id = wc*mysinc(wc*m);                  
wFIR = 0.54 - 0.46*cos(2*pi*(0:lpN-1)/(max(lpN-1,1))); wFIR = wFIR(:).';
h = h_id .* wFIR;                        
h = h / sum(h);                         
s_rec = myfiltfilt(h, 1, s_dem);         

W = linspace(-fs/2, fs/2, N0);
figure('Name','Fig7');
subplot(3,1,1); plot(W, abs(fftshift(fft(xseg)))); grid on;
title('Fig.7(a) Spectrum: Original'); xlabel('Hz');
subplot(3,1,2); plot(W, abs(fftshift(fft(s_mod)))); grid on;
title('Fig.7(b) Spectrum: AM-modulated'); xlabel('Hz');
subplot(3,1,3); plot(W, abs(fftshift(fft(s_rec)))); grid on;
title('Fig.7(c) Spectrum: Demodulated + LPF'); xlabel('Hz');

hideAxesToolbars(gcf);
exportgraphics(gcf, fullfile(outdir,'Fig7_am_chain_spectra.png'), 'Resolution', 300);

function [S, f, tt] = stft_nontbx(x, fs, w, hop, nfft)

x = x(:);
win = numel(w);
if numel(x) < win
    win = numel(x);
    w   = w(1:win);
end
hop = max(1, hop);
nFrames = 1 + floor((numel(x)-win)/hop);
if nFrames < 1, nFrames = 1; end
S = zeros(nfft, nFrames);
for i = 1:nFrames
    startIdx = (i-1)*hop + 1;
    frame = zeros(nfft,1);
    xw = x(startIdx : startIdx+win-1) .* w;
    frame(1:win) = xw;
    S(:,i) = fft(frame);
end
S = S(1:floor(nfft/2)+1, :);            
f  = (0:floor(nfft/2))'/nfft * fs;     
tt = ((0:nFrames-1)*hop + win/2) / fs;  
end

function [r, lags] = xcorr_basic(x, y)
x = x(:); y = y(:);
r = conv(x, flipud(y));
lags = -(numel(y)-1) : (numel(x)-1);
end

function y = myfiltfilt(b, a, x)
x = x(:);
y = filter(b, a, x);
y = flipud(y);
y = filter(b, a, y);
y = flipud(y);
end

function y = mysinc(x)
y = ones(size(x));
nz = (x ~= 0);
y(nz) = sin(pi*x(nz)) ./ (pi*x(nz));
end

function hideAxesToolbars(fig)
axs = findall(fig,'type','axes');
for i = 1:numel(axs)
    try, axs(i).Toolbar.Visible = 'off'; end
    try, disableDefaultInteractivity(axs(i)); end
end
drawnow;
end